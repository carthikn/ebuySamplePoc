function crtSelOpt(dataAL,compid,val,styleclass){
	$("#"+compid+" option").remove();
	var obj=document.getElementById(compid);
	if(obj==null){
		return;
	}
	var fragment=document.createDocumentFragment();
    var opt;
    opt=document.createElement("option");
	opt.innerHTML="";
    opt.value="";	
    //fragment.appendChild(opt);
	for(var x=0;x<dataAL.length;x++){
		var tmpArr=dataAL[x].split("\t");
		opt=document.createElement("option");
		opt.innerHTML=tmpArr[1];
	    opt.value=tmpArr[0];
	    if(styleclass!=''){
	    	opt.className=styleclass;
	    }
	    
	    fragment.appendChild(opt);
	}
	obj.appendChild(fragment.cloneNode(true));
	$("#"+compid).val(val);
	$("#"+compid).focus();
}

function crtSelOpt(dataAL,compid,val,styleclass){
	$("#"+compid+" option").remove();
	var obj=document.getElementById(compid);
	if(obj==null){
		return;
	}
	var fragment=document.createDocumentFragment();
    var opt;
    opt=document.createElement("option");
	opt.innerHTML="";
    opt.value="";	
    //fragment.appendChild(opt);
	for(var x=0;x<dataAL.length;x++){
		var tmpArr=dataAL[x].split("\t");
		opt=document.createElement("option");
		opt.innerHTML=tmpArr[1];
	    opt.value=tmpArr[0];
	    if(styleclass!=''){
	    	opt.className=styleclass;
	    }
	    
	    fragment.appendChild(opt);
	}
	obj.appendChild(fragment.cloneNode(true));
	$("#"+compid).val(val);
	$("#"+compid).focus();
}

function crtSelOpt4MultiData(dataAL,compid,val,styleclass){
	$("#"+compid+" option").remove();
	var obj=document.getElementById(compid);
	if(obj==null){
		return;
	}
	var fragment=document.createDocumentFragment();
    var opt;
    opt=document.createElement("option");
	opt.innerHTML="";
    opt.value="";	
    //fragment.appendChild(opt);
	for(var x=0;x<dataAL.length;x++){
		var tmpArr=dataAL[x].split("\t");
		opt=document.createElement("option");
		opt.innerHTML=tmpArr[2];
	    opt.value=dataAL[x];
	    if(styleclass!=''){
	    	opt.className=styleclass;
	    }
	    
	    fragment.appendChild(opt);
	}
	obj.appendChild(fragment.cloneNode(true));
	$("#"+compid).val(val);
	$("#"+compid).focus();
}


