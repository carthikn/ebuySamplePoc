var spApp = angular.module("spApp", ['ui.grid', 'ui.grid.edit', 'ui.grid.cellNav', 'ui.grid.resizeColumns','ui.grid.pagination'])
spApp.controller('contrl', ['$scope','$http', '$timeout', function($scope,$http, $timeout) {

	$scope.itemSelected='product';
	$scope.chartSelected='Table';
	var arr1 =[];
			var arr2 =[];
			var arr3=[];
	$scope.fieldsAvalilable=[];
	$scope.charttypeList=[{"name":"Table"},{"name":"Bar Chart"},{"name":"Pie Chart"},{"name":"Line Chart"}];
	$scope.gridOptions = {
		paginationPageSizes: [30, 60, 90],
		paginationPageSize: 30,
        enableSorting: true,
        enableGridMenu: true,
        enableFiltering: true,
        columnDefs: [
            { name: 'Id', field: 'id', enableCellEdit: false, type:'number', cellTemplate: '<a href="javascript:void(0)" ng-click="grid.appScope.gotoClient(row.entity)">{{row.entity.id}}</a>' },
            { name: 'Txn Id', field: 'txnt_id', enableCellEdit: false,type:'number',cellTemplate: '<a href="javascript:void(0)" ng-click="grid.appScope.gotoClient(row.entity)">{{row.entity.txnt_id}}</a>'},
            { name: 'User name', field: 'username', enableCellEdit: false },
            { name: 'Product Zone', field: 'product_zone', enableCellEdit: false },
            { name: 'Product', field: 'product', enableCellEdit: false},
            { name: 'Brand', field: 'brand', enableCellEdit: false},
            { name: 'Model', field: 'model', enableCellEdit: false },
            { name: 'DateTime', field: 'date_time', enableCellEdit: false},
            { name: 'Quantity', field: 'quantity', enableCellEdit: false,type:'number' },
            { name: 'Amount', field: 'amount', enableCellEdit: false,type:'number' }
        ],
        onRegisterApi: function( gridApi ) {
            $scope.gridApi = gridApi;
              $scope.gridApi.core.on.filterChanged( $scope, function() {
                var grid = this.grid;
               
          });
        
    }
};
	$scope.loadData = function () {
		/*$http.post($scope.configObj.queryURL).then(function(result){
			var data = result.data.data;
			$scope.gridOptions.data = data;
		})*/
		$http({
            method : "POST",
            url : "/getEbuydata",
            data:{}
        }).then(function mySuccess(result) {
        	//console.log('resonse.data',JSON.stringify(response.data));
        	var data = result.data.data;
			$scope.gridOptions.data = data;
			var fieldList = Object.keys(data[0]);
			for(var k=0;k<fieldList.length;k++){
				var listObj={}
				listObj.name = fieldList[k];
				listObj.id = k;
				$scope.fieldsAvalilable.push(listObj);
			}
        }, function myError(response) {
           console.log("response.statusText:"+response.statusText);
        });
	};
	$scope.loadData();
    $scope.gotoCaller = function () {
        $state.go('spcaller');
    }

    $scope.gotoClient = function (row) {
        console.log(row);
    }
    
    
	$scope.aggregategridOptions = {
        enableSorting: true,
        enableGridMenu: true,
        enableFiltering: true,
        columnDefs: [
            { name: 'Product', field:'product', enableCellEdit: false, cellTemplate: '<a href="javascript:void(0)" ng-click="grid.appScope.gotoClient(row.entity)">{{row.entity.product}}</a>' },
            { name: 'Count', field: 'count', enableCellEdit: false,cellTemplate: '<a href="javascript:void(0)" ng-click="grid.appScope.gotoClient(row.entity)">{{row.entity.count}}</a>'},
            { name: 'Total', field: 'total', enableCellEdit: false },
            { name: 'Minimum', field: 'min', enableCellEdit: false },
            { name: 'Maximum', field: 'max', enableCellEdit: false},
            { name: 'Average', field: 'avg', enableCellEdit: false},
            { name: 'Num of Users', field: 'nval', enableCellEdit: false },
        ],
        onRegisterApi: function( gridApi ) {
            $scope.gridApi = gridApi;
              $scope.gridApi.core.on.filterChanged( $scope, function() {
                var grid = this.grid;
               
          });
        
    }
};
	 $scope.setSelecteditem=function(item) {
	 	arr1=[];
	 	arr2=[];
	 	arr3=[];
		 $scope.itemSelected=item;
		 var obj={};
			obj.name = $scope.itemSelected;
			obj.field = $scope.itemSelected;
			console.log(obj);
			$scope.aggregategridOptions.columnDefs.shift();
			$scope.aggregategridOptions.columnDefs.unshift(obj);
			
			$scope.loadDataAggregate(item);
		}
	 $scope.setSelectedchart=function(item) {
		 $scope.chartSelected=item;
		 if (item=="Line Chart") {
		 	var chart = c3.generate({
		 		bindto: "#chart",
			    data: {
			        columns: [
			            arr2
			        ]
			    },
			    axis: {
			        x: {
			            type: 'category',
			            categories: arr1
			        }
			    }
			});
		 }else if(item=="Pie Chart"){
		 	var chart = c3.generate({
		 		bindto: "#chart",
			    data: {
			        columns: 
			            arr3
			        ,type:"pie"
			    },
			    axis: {
			        x: {
			            type: 'category',
			            categories: arr1
			        }
			    }
			});
		 }
		 else if(item=="Bar Chart"){
		 	var chart = c3.generate({
		 		bindto: "#chart",
			    data: {
			        columns: [
			            arr2
			        ],type:"bar"
			    },
			    axis: {
			        x: {
			            type: 'category',
			            categories: arr1
			        }
			    }
			});
		 }
	 }

	$scope.loadDataAggregate = function (grpBy,val,count) {
		var params = {
				grpbyField:grpBy,
				valueField:"amount",
				countFiled:"username"
		}
		
		$http({
            method : "POST",
            url : "/getEbuydataAggregate",
            data:{params:params}
        }).then(function mySuccess(result) {
        	//console.log('resonse.data',JSON.stringify(response.data));
        	var data = result.data.data;
			$scope.aggregategridOptions.data = data;
			
			arr2.push($scope.itemSelected);
			for(var l=0;l<data.length;l++){
				 var arr4=[];

				if(arr1.indexOf(data[l][$scope.itemSelected])==-1){
					arr1.push(data[l][$scope.itemSelected]);
					arr2.push(data[l].total);
					arr4.push(data[l][$scope.itemSelected],data[l].total)
					arr3.push(arr4);

				}

			}
			console.log(arr3);
			
        }, function myError(response) {
           console.log("response.statusText:"+response.statusText);
        });
		
	};
	$scope.loadDataAggregate($scope.itemSelected);
}])