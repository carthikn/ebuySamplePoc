function validateUname(){
	var focusid="uname";
	var errorMsg="";
	var uname=$("#uname").val();
	if(uname==undefined || uname.trim()==''){
		$("#"+focusid+"_req").show();
		return false;
	}
	$("#"+focusid+"_req").hide();
	return true;
}
function validatePaswd(){
	var focusid="paswd";
	var errorMsg="";
	var paswd=$("#paswd").val();
	if(paswd==undefined || paswd.trim()==''){
		$("#"+focusid+"_req").show();
		return false;
	}
	$("#"+focusid+"_req").hide();
	return true;
}

function processLogin(){
	var validated=true;
	if(!validateUname()){
		validated=false;
	}
	if(!validatePaswd()){
		validated=false;
	}
	if(!validated){
		return false;
	}
}