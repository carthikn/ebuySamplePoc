// JavaScript Document


  (function() {
  'use strict';

   // var app = angular.module('app', ['ngMaterial'])
	
	app.config(function($mdThemingProvider) {

  $mdThemingProvider.definePalette('amazingPaletteName', {
    '50': 'ffebee',
    '100': 'ffcdd2',
    '200': 'ef9a9a',
    '300': 'e57373',
    '400': 'ef5350',
    '500': '00a0ac', // my pallette color
    '600': '0daebb',
    '700': 'd32f2f',
    '800': 'c62828',
    '900': 'b71c1c',
    'A100': 'ff8a80',
    'A200': 'ff5252',
    'A400': 'ff1744',
    'A700': '0daebb',
    'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                        // on this palette should be dark or light

    'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
     '200', '300', '400', 'A100'],
    'contrastLightColors': undefined    // could also specify this if default was 'dark'
  });

$mdThemingProvider.definePalette('accentPaletteName', {
    '50': '0fa8e8',
    '100': 'ffcdd2',
    '200': '0fa8e8',
    '300': '0fa8e8',
    '400': '0fa8e8',
    '500': '0fa8e8', // my pallette color
    '600': 'e53935',
    '700': 'd32f2f',
    '800': 'c62828',
    '900': 'b71c1c',
    'A100': 'ff8a80',
    'A200': 'ffd166', // my accent pallette color
    'A400': 'ff1744',
    'A700': 'ffcf5e',
    'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                        // on this palette should be dark or light

    'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
     '200', '300', '400', 'A100'],
    'contrastLightColors': undefined    // could also specify this if default was 'dark'
  });
 


  $mdThemingProvider.theme('default')
    .primaryPalette('amazingPaletteName')
	.accentPalette('accentPaletteName');

})

	
	
	
	
      .config(function($mdIconProvider) {
        $mdIconProvider
          .iconSet("call", 'img/icons/sets/communication-icons.svg', 24)
          .iconSet("social", 'img/icons/sets/social-icons.svg', 24);
      })
	

    .controller('DemoCtrl', function($scope, $mdDialog, $timeout, $mdSidenav) {
      var self = this;

      self.hidden = false;
      self.isOpen = false;
      self.hover = false;

      // On opening, add a delayed property which shows tooltips after the speed dial has opened
      // so that they have the proper position; if closing, immediately hide the tooltips
      $scope.$watch('demo.isOpen', function(isOpen) {
        if (isOpen) {
          $timeout(function() {
            $scope.tooltipVisible = self.isOpen;
          }, 600);
        } else {
          $scope.tooltipVisible = self.isOpen;
        }
      });

      self.items = [
        { name: "Graph", 		icon: "fa-area-chart", 	direction: "bottom" },
        { name: "Text", 		icon: "fa-font", 		direction: "top" 	},
        { name: "Analysis", 	icon: "fa-bar-chart", 	direction: "bottom" },
		{ name: "Table", 		icon: "fa-table", 		direction: "top" 	},
		{ name: "Data Models", 	icon: "fa-database", 	direction: "bottom" }
      ];

      self.openDialog = function($event, item) {
        // Show the dialog
        $mdDialog.show({
          clickOutsideToClose: true,
          controller: function($mdDialog) {
            // Save the clicked item
            this.item = item;

            // Setup some handlers
            this.close = function() {
              $mdDialog.cancel();
            };
            this.submit = function() {
              $mdDialog.hide();
            };
          },
          controllerAs: 'dialog',
          templateUrl: 'dialog.html',
          targetEvent: $event
        });
      };
	  
	  // Side Nav
		$scope.showMobileMainHeader = true;
		$scope.openSideNavPanel = function() {
			$mdSidenav('left').open();
		};
		$scope.closeSideNavPanel = function() {
			$mdSidenav('left').close();
		};

	  
	  var originatorEv;
    
        this.openMenu = function($mdOpenMenu, ev) {
          originatorEv = ev;
          $mdOpenMenu(ev);
        };
    
        this.notificationsEnabled = true;
        this.toggleNotifications = function() {
          this.notificationsEnabled = !this.notificationsEnabled;
        };
    
        this.redial = function() {
          $mdDialog.show(
            $mdDialog.alert()
              .targetEvent(originatorEv)
              .clickOutsideToClose(true)
              .parent('body')
              .title('Suddenly, a redial')
              .textContent('You just called a friend; who told you the most amazing story. Have a cookie!')
              .ok('That was easy')
          );
    
          originatorEv = null;
        };
    
        this.checkVoicemail = function() {
          // This never happens.
        };
	  
	  
    });
	
})();
	
  
