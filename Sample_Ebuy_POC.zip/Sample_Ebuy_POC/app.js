
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path')
  , MongoClient = require('mongodb').MongoClient
  ,assert = require('assert')
  ,mongo=require('mongodb')
  , request = require('request')
  ,session = require('express-session');
var _ = require('lodash');
var async = require("async");
var dateFormat = require('dateformat');
var app = express();
app.use(session({
    secret: "fd34s@!@dfa453f3DF#$D&W",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: !true }, expires: new Date(Date.now() + (3))
}));

app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
//app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));
app.use('/questions', express.static(path.join(__dirname, 'public')))
app.engine('html', require('ejs').renderFile);

if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.post('/', routes.index);
app.get('/users', user.list);

app.get('/',function(req,res){
	res.render('index.html');
});

app.post('/getEbuydata',function(req,res){
	
	MongoClient.connect('mongodb://localhost:27017/ebuyDataList', function(err, db) {
		
		db.collection('ebuyList').find({}).toArray(function(err, dataRes) {
			if (err) {
				return handleError(err);
			} else {
				async.forEach(dataRes, function(item, cb) {
					item.date_time=dateFormat(item.date_time, "mm-dd-yyyy");
					item.id=item.id;
					item.amount=item.amount;
					item.quantity=item.quantity;
					cb();

				}, function(err) {
					res.json({
						type: true,
						data: dataRes
					});
					db.close();
				})


			}
		});
	});
	
});
app.post('/getEbuydataAggregate',function(req,res){
	
	MongoClient.connect('mongodb://localhost:27017/ebuyDataList', function(err, db) {
		var query=[];
		var grpbyField = req.body.params.grpbyField;
		var valueField = req.body.params.valueField;
		var countFiled = req.body.params.countFiled;

		var filterQuery = {"$group": {
			"_id":"$"+grpbyField,
			"count": {
				"$sum": 1
			},
			"tot": {
				"$sum": "$"+valueField
			},
			"min": {
				"$min": "$"+valueField
			},
			"max": {
				"$max": "$"+valueField
			},"avg": {
				"$avg": "$"+valueField
			},
			"totalNum": {
				"$addToSet": "$"+countFiled
			}
		}};
		query.push(filterQuery);
		db.collection('ebuyList').aggregate(query).toArray(function(err, dataResult) {
			if (err) {
				return handleError(err);
			} else {
				var outpuArr=[];
				for(var x=0;x<dataResult.length;x++){
					var resObj = {};
					var nval = dataResult[x].totalNum;
					resObj[grpbyField] =dataResult[x]._id;
					resObj.count =dataResult[x].count;
					resObj.total =dataResult[x].tot;
					resObj.min =dataResult[x].min;
					resObj.max =dataResult[x].max;
					resObj.avg =dataResult[x].avg.toFixed(2);
					resObj.nval =nval.length;
					outpuArr.push(resObj)
				}

				res.json({
					type: true,
					data: outpuArr
				});
				db.close();
			}
		});
	});
	
});

http.createServer(app).listen(app.get('port'), function(){
	  console.log('Express server listening on port ' + app.get('port'));
});

